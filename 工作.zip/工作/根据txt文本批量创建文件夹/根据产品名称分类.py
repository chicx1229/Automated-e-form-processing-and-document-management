import os
import shutil
path = r"F:\20923\Desktop\final"
import  re
def file_name(file_path):
    try:
        #创建一个字典来保存产品人的文件夹
        folders = {}
        for root, dirs, files in os.walk(file_path):
            array = dirs
            for file_line in array:
                print("产品和产品人信息:", file_line)
                match = re.match(r'(.+)-(.+)', file_line)
                if match:
                    goods_name = match.group(1).strip()
                    belong_name = match.group(2).strip()
                # goods_name, belong_name = file_line.split('-')
                # strip()方法移除字符串头尾指定的字符
                belong_name = belong_name.strip()
                # 获取新文件夹的路径
                folder_path = os.path.join(path,belong_name)
                # 检查产品人文件夹是否存在,不在则创建,并加入字典中
                if belong_name not in folders:
                # if not(os.path.exists(belong_name)):
                    os.makedirs(folder_path)
                    folders[belong_name] = folder_path
                    print(belong_name + "---OK---")
                else:
                    print(belong_name + "---There is this folder!---")
                #移动产品文件夹到新的位置
                source_file = os.path.join(root,file_line)
                shutil.move(source_file,folder_path)
                print(f"{source_file}--------move-------ok")

    except Exception as e:
        print(e)

if __name__ == '__main__':
    # makedirsAccordingToName()
    file_name(path)


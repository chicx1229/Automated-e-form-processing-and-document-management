# 名字长度 2-7的自然数
import random

name_length = 2
# 南方1 北方2 分不清3
north_south = 2
# 男1 女2
gender = 1
cards = [1,2,3,4]
cards = cards + cards
print("将一副牌撕开: " + str(cards)) # [1, 2, 3, 4, 1, 2, 3, 4]
# 将队头的name_length张牌插入队尾
for _ in range(name_length):
    cards.append(cards.pop(0))
print("按照名字字数n,将牌顶n张牌放入牌底: " + str(cards))  # [3, 4, 1, 2, 3, 4, 1, 2]

#将队头的三个元素插入中间
top_three = cards[:3]
last_five = cards[3:]
# 随机生成插入位置
location = random.randint(1,4)
cards = last_five[:location]+top_three+last_five[location:]
print("拿起最上面三张牌,插到中间去: " + str(cards)) #[2, 3, 4, 3, 4, 1, 1, 2]

under_butt = cards.pop(0)
print("将最上面的牌放到屁股下面: "+ str(under_butt))

# 根据南北方人丢掉对应的牌数
for _ in range(north_south):
    cards.pop(0)
print("根据南北方人丢掉对应的牌数: " + str(cards)) #[3, 4, 3, 4, 1, 1, 2]

for _ in range(gender):
    cards.pop(0)
print("如果是男生从上面拿一张,是女生拿两张,撒到空中去: " + str(cards)) #[3, 4, 3, 4, 1, 1, 2]

# 见证奇迹的时刻
for _ in range(7):
    cards.append(cards.pop(0))
print("见证奇迹的时刻: " + str(cards)) #[3, 4, 1, 3, 4, 1, 2]
print("-------------------- 见证奇迹的时刻---------------------")
while len(cards) > 1:
    print("好运留下来: " + str(cards[0]) )
    cards.append(cards.pop(0))
    print("烦恼丢出去: "+ str(cards[0]) )
    cards.pop(0)
    print(cards)

print("屁股底下的牌: " + str(under_butt))
print(cards[0] == under_butt)
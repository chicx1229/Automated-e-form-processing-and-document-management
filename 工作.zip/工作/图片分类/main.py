import easyocr
import openpyxl
import os
import shutil
from pathlib import Path
import re

path = r"F:\20923\Desktop\tupian"

# 1.读取每张图片的地址
def get_source(path):
    pic_source = []
    for root, dirs, pictures in os.walk(path):
        for picture in pictures:
            pic_source.append(os.path.join(root,picture))
# 2.识别每张图片文字,并按照识别的名字进行文件夹分类,同时写到excel中
    for every_pic in pic_source:
        get_information(every_pic)


def get_information(image):
    # 创建EasyOCR Reader
    ocr = easyocr.Reader(['ch_sim'], gpu=True)
    data2 = ['aa', 'aa', '辉煌']
    textlist = []

    # 使用EasyOCR进行文本提取  读取图像并进行文本识别
    result = ocr.readtext(image)
    # 其中，bbox表示文本所在的边界框（bounding box），text表示提取的文本内容，prob表示文本的置信度或概率。
    for (bbox, text, prob)  in result:
        textlist.append(text)  # detection[1] 识别的文本
    print(textlist)
    # 使用正则表达式提取姓名和电话号码
    textlist_str = ','.join(textlist)  # 将列表内的字符串连接成一个字符串
    print(textlist_str)
    matches = re.findall(r'([\u4e00-\u9fff]+)(1\d{10})', textlist_str)
     # shutil.copy(image, r'F:\20923\Desktop\problems')
    for match in matches:
        print("姓名:", match[0])
        print("电话:", match[1])



# 3.删除path文件夹中的图片 并将有问题的图片写到problems中


get_source(path)
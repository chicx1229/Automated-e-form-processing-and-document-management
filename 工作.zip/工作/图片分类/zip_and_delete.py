import os
import zipfile

def unzip_and_delete(zip_file_path):
    # 解压缩文件
    with zipfile.ZipFile(zip_file_path, 'r') as zip_ref:
        zip_ref.extractall(os.path.dirname(zip_file_path))

    # 删除压缩包
    os.remove(zip_file_path)
    print(f"已解压缩并删除文件: {zip_file_path}")

def unzip_all_and_delete(folder_path):
    for dirpath, _, filenames in os.walk(folder_path):
        print(dirpath)
        print(filenames)
        for filename in filenames:
            file_path = os.path.join(dirpath, filename)
            # print(file_path)
            if zipfile.is_zipfile(file_path):
                unzip_and_delete(file_path)

# 设置要操作的文件夹路径
folder_path = r"F:\20923\Desktop\123."

# 执行解压缩和删除操作
unzip_all_and_delete(folder_path)
input("Press Enter to exit...")
import  os
import  shutil

paths = r"F:\20923\Desktop\final"
dirs = []
files = []
def get_files(paths):
    for item in os.scandir(paths):
        if item.is_dir():
            dirs.append(item.path)
        elif item.is_file():
            files.append(item.path)
    print("dirs: ")
    print('\n'.join(dirs))
    print()
    print("files: ")
    print('\n'.join(files))

def  traversal_files(path):
    # path:白茶+茶研刺梨植物饮料-八月阿伟
    # if os.path.isdir(path):
    for item in os.scandir(path):
        # item:茶研刺梨植物+白茶
        # 递归调用自身处理子文件夹
        if item.is_dir():
            traversal_files(item.path)
            # 将子文件夹中的文件移动到当前文件夹
            for sub_item in os.scandir(item.path):
                if sub_item.is_file():
                    shutil.move(sub_item.path, path)
            # 删除空的子文件夹
            os.rmdir(item.path)


if __name__ == '__main__':
    get_files(paths)
    for path in dirs:
        traversal_files(path)

import os
import glob

# 设置文件夹路径
folder_path = r"F:\20923\Desktop\class"
all_paths = []

# 使用glob模块查找文件夹中的所有文件夹路径
for root, dirs, files in os.walk(folder_path):
    all_paths.append(root)

# 遍历每个文件夹路径
for path in all_paths:
    # 使用glob模块获取文件夹中的所有文件路径
    file_list = glob.glob(os.path.join(path, '*'))
    # 获取当前文件夹的名称
    folder_name = os.path.basename(path)
    # 统计文件数量
    file_count = len(file_list)
    # 打印结果
    print(f'{folder_name}中的文件数量为：{file_count}')
input("Press Enter to exit...")
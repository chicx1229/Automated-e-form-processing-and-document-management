import easyocr
import openpyxl
import os
import shutil
from pathlib import Path

path = r"F:\20923\Desktop\tupian"


# 创建EasyOCR Reader
ocr = easyocr.Reader(['ch_sim'], gpu=True)

data1 = [[]]
changeFile = {}
imageList = []
def traverse_dir(path):
    for root, dirs, files in os.walk(path):
        for file in files:
            file_path = os.path.join(root, file)
            print("文件：", file_path)
            imageList.append(file_path)
    print("共",len(imageList),"张图片")
    for image in imageList:
        # 遍历每张图片
        extractSave(image)

def extractSave(image):
    textlist = []
    data2 = ['aa','aa','茅子']
    # 使用EasyOCR进行文本提取
    results1 = ocr.readtext(image,detail=0)
    results2 = ocr.readtext(image)
    print(results1);print(results2)

    for i in range(len(textlist)):
        # 检查当前元素以 "待发" 开头，并且下下个元素以字符 '1' 开头。
        if textlist[i].startswith("待发") and textlist[i + 2].startswith('1'):
            # 若满足 将姓名和电话加入到列表第一列中
            data2[0] = textlist[i + 1] + textlist[i + 2]
        # 这个条件判断语句检查当前元素以 "待发" 开头，并且下一个元素不以字符 '1' 开头。
        elif textlist[i].startswith("待发") and (not textlist[i + 2].startswith('1')):
            # 若满足 将姓名加入到列表第一列中
            data2[0] = textlist[i + 1]
        # 这个条件判断语句检查当前元素以 "实付" 开头，并且不以 "实付款" 开头。
        elif textlist[i].startswith("实付") and (not textlist[i].startswith("实付款")):
            if 'aa' == data2[1]:
                # 若满足 将产品名称添加到列表第二列中
                data2[1] = textlist[i - 1]
            else:
                # 将列表第二列与当前元素的前一个元素以加号 '+' 进行拼接。
                data2[1] = data2[1] + '+' + textlist[i - 1]
                break
        #         当前元素不以 "实付" 开头，并且包含子字符串 '实付'。
        elif (not textlist[i].startswith("实付")) and ('实付' in textlist[i]):
            if 'aa' == data2[1]:
                # 当前元素中从开头到 '实付' 第一次出现的子字符串。
                data2[1] = textlist[i][0:textlist[i].find('实付')]
            else:
                # 将 data2 列表的第二个元素与当前元素中从开头到 '实付' 第一次出现的子字符串以加号 '+' 进行拼接。
                data2[1] = data2[1] + '+' + textlist[i][0:textlist[i].find('实付')]
                break
    if data2[0] == 'aa' or data2[1] == 'aa':
                  # 有问题的图片
                shutil.copy(image,r'F:\20923\Desktop\problems')
            # 产品名称
    changeFile[image] = data2[1]
    data1.append(data2)


def createDic(fileDict: dict):
    old_file = list(fileDict.keys())
    new_file = list(fileDict.values())
    print(old_file)
    print(new_file)
    for i in range(len(new_file)):
        new1 = new_file[i].replace(':','').replace(' ','').replace('.','').replace('"','')
        newFilename1 = Path(rf'F:\20923\Desktop\class') / new1
        if newFilename1.exists():
            shutil.copy(old_file[i], newFilename1)
        else:
            newFilename1.mkdir(parents=True, exist_ok=True)
            shutil.copy(old_file[i], newFilename1)



if __name__ == '__main__':
    #提取图片内容
    traverse_dir(path)
    print(changeFile.items())
    # 创建一个新的Excel文件
    workbook = openpyxl.Workbook()
    #选择第一个工作表
    sheet = workbook.active
    for row in data1:
        sheet.append(row)
    # 保存文件
    workbook.save('茅子.xlsx')
    createDic(changeFile)
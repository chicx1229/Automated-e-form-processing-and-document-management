import  os
import shutil

# 获取文件夹路径和名称
# sourse_subdirs = [d for d in os.listdir(sourse_dir) if os.path.isdir(os.path.join(sourse_dir,d))]
# final_subdirs = [d for d in os.listdir(final_dir) if os.path.isdir(os.path.join(final_dir,d))]

sourse_dir = r"F:\20923\Desktop\class"
final_dir = r"F:\20923\Desktop\final"

sourse_subdirs = [d for d in os.listdir(sourse_dir)]
final_subdirs = [d for d in os.listdir(final_dir)]

for source_subdir in sourse_subdirs:
    char_dict = {}

    # 遍历源文件夹中的每个字符
    for char in source_subdir:
        # 遍历目标文件夹
        for final_subdir in final_subdirs:
            if char in final_subdir:
                if final_subdir in char_dict:
                    char_dict[final_subdir] += 1
                else:
                    char_dict[final_subdir] = 1

    # 找到值最大的目标文件夹
    max_value_file = max(char_dict, key=char_dict.get)

    # 检查是否其他字典与最大值字典值相同
    same_count = [k for k, v in char_dict.items() if v == char_dict[max_value_file]]

    if len(same_count) > 1:
        print(f"---有{len(same_count)}个目标文件夹,子文件夹{source_subdir}不移动---")
        print(f"目标文件夹有{max_value_file},{same_count}")
        continue
    # 将源文件夹移动到值最大的目标文件夹中
    source_path = os.path.join(sourse_dir, source_subdir)
    final_path = os.path.join(final_dir, max_value_file)
    print(f"将子文件夹{source_subdir}移动至{max_value_file}")
    shutil.move(source_path, final_path)
    # 上一行代码可能会移动文件夹，务必小心


    # for dir in dirs:
    #     print(dir)
    #     for final_root, final_dirs, final_files in os.walk(final_dir):
    #         for final_dir in final_dirs:
    #             print('1',final_dir)




# 遍历目标文件夹 寻找名称是否存在于目标文件夹中 若是则放入